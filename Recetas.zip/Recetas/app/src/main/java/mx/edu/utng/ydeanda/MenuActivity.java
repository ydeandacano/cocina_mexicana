package mx.edu.utng.ydeanda;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

import mx.edu.utng.ydeanda.Sopas;

public class MenuActivity extends AppCompatActivity {
    private TextView txtSopas;
    private TextView txtMariscos;
    private TextView txtEnsaladas;
    private TextView txtVerduras;
    private TextView txtCarnes;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        txtSopas = (TextView)findViewById(R.id.txtSopas);
        txtMariscos = (TextView)findViewById(R.id.txtMariscos);
        txtEnsaladas = (TextView)findViewById(R.id.txtEnsaladas);
        txtVerduras = (TextView)findViewById(R.id.txtVerduras);
        txtCarnes = (TextView)findViewById(R.id.txtCarnes);

        txtSopas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intVerMenu = new Intent(getApplicationContext(),
                       Sopas.class);
                startActivity(intVerMenu);
            }
        });
    }
}
