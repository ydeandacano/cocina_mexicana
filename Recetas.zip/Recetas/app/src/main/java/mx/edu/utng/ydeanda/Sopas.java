package mx.edu.utng.ydeanda;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Sopas extends AppCompatActivity {
    private TextView txtTortilla;
    private TextView txtTarasca;
    private TextView txtLima;
    private TextView txtCastellana;
    private TextView txtChilpachole;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        setContentView(R.layout.activity_sopas);

        txtTortilla=(TextView)findViewById(R.id.txtTortilla);
        txtTarasca=(TextView)findViewById(R.id.txtTarasca);
        txtLima=(TextView)findViewById(R.id.txtLima);
        txtCastellana=(TextView)findViewById(R.id.txtCastellana);
        txtChilpachole=(TextView)findViewById(R.id.txtChilpachole);

        txtTortilla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Ver", Toast.LENGTH_SHORT).show();
            }
        });
        txtTarasca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Ver", Toast.LENGTH_SHORT).show();
            }
        });
        txtLima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Ver", Toast.LENGTH_SHORT).show();
            }
        });
        txtCastellana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Ver", Toast.LENGTH_SHORT).show();
            }
        });
        txtChilpachole.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Ver", Toast.LENGTH_SHORT).show();
            }
        });
    }
}